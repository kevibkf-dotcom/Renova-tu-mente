RENOVÁ TU MENTE — proyecto Android

Incluye una app Android nativa tipo WebView y una versión web instalable (PWA).
Funciones: calendario mensual con estados, racha actual, conteo de días, lista de 7 días,
versículos bíblicos, estrategia para momentos difíciles y nota personal. Los datos se guardan
localmente en el dispositivo con localStorage.

IMPORTANTE:
- Este paquete contiene el PROYECTO FUENTE, no un APK compilado.
- En este entorno no está instalado Android SDK/Gradle, por lo que no puedo compilar ni verificar
  un APK aquí.
- Para compilar: abrir la carpeta en Android Studio con Android SDK instalado, sincronizar Gradle
  y elegir Build > Build APK(s). El APK de depuración suele quedar en app/build/outputs/apk/debug/.
- Para probar sin compilar APK: servir app/src/main/assets por HTTPS y añadir la web app desde Chrome
  usando el menú > Añadir a pantalla de inicio. La PWA necesita alojarse para ser instalable como PWA.
- El calendario y las notas se guardan localmente; no hay cuenta ni sincronización en la nube.
